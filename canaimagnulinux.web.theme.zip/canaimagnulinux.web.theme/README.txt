Place Diazo resources here, including rule and theme sources.

It's common to develop these resources interactively via the Plone theming editor (Plone 4.3+), then export the resources and install them here.